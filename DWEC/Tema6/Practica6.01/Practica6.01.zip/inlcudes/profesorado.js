"use strict";

export class Profesorado{
    //Constructor con los datos básicos para el profesorado.
    constructor(pNom, pApellidos, pDni){
        this.dni = pDni;
        this.nombre = pNom;
        this.apellidos = pApellidos;
    }
    
}