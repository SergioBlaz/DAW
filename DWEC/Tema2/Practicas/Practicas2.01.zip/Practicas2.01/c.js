"use strict";

function Multiplicanumeros(par1, par2){
    for (var i=0; i<par1; i++){
        console.log(par2);
        par2 = par2*2;
    } 
}
Multiplicanumeros(4,6);