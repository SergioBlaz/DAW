<?php
// src/Controller/Tarea1.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class Tarea1 extends AbstractController{
    /**
     * @Route ("/calculadora/{num1}/{num2}", name="calculadora")
     */
    public function calculadora($num1, $num2){
        $sum = $num1 + $num2;
        $res = $num1 - $num2;
        $div = $num1 / $num2; 
        $mul = $num1 * $num2;
        $mod = $num1 % $num2;
        return $this->render('calculadora.html.twig', array ('sum'=>$sum, 'res'=>$res, 'div'=>$div, 'mul'=>$mul, 'mod'=>$mod));
    }
    /**
     * @Route ("/factorial/{num}", name="factorial")
     */
    public function factorial($num){
        $factorial = 1;

        for($x=$num; $x>=1; $x--){
            $factorial = $factorial * $x;
        }

        return $this->render('factorial.html.twig', array ('num'=>$num, 'factorial'=>$factorial));
    }
    /** 
     * @Route ("/aleatorio", name="aleatorio") 
     */
    public function aleatorio(){
        $num = random_int(1, 100);
        return $this->render('aleatorio.html.twig', array('num'=>$num));
    }
    /**
     * @Route ("/areatriangulo/{b}/{h}", name="areatriangulo")
     */
    public function areatriangulo($b, $h){
        $a = ($b * $h)/2;
        return $this->render('areatriangulo.html.twig', array('b'=>$b, 'h'=>$h, 'a'=>$a));
    }
    /**
     * @Route ("/palindromo/{palabra}", name="palindromo")
     */
    public function palindromo($palabra){
        $reves = strrev($palabra);
        return $this->render('palindromo.html.twig', array('palabra'=>$palabra, 'reves'=>$reves));
    }
    /**
     * @Route ("/sumatorio", name="sumatorio")
     */
    public function sumatorio(){
        $rnd = random_int(1,20);
        $sum = 0;
        for($i=1; $i<=$rnd; $i++){
            $sum = $sum + $i;
        }
        return $this->render('sumatorio.html.twig', array('rnd'=>$rnd, 'sum'=>$sum));
    }
    /**
     * @Route ("/ecuacion/{a}/{b}/{c}", name="ecuacion")
     */
    public function ecuacion($a, $b, $c){
        $neg = -1; 

        $menosb = $b * $neg; 
        $oper1 = pow($b,2); 
        $oper2 = 4*$a*$c; 
        $resta = $oper1-$oper2; 
        $raiz = pow($resta,(1/2)); 
        $dosa = 2*$a; 

        $result1 = ($menosb + $raiz)/$dosa; 
        $result2 = ($menosb - $raiz)/$dosa; 

        return $this->render('ecuacion.html.twig', array('result1'=>$result1, 'result2'=>$result2));
    }
    /**
     * @Route ("/esprimo/{num}", name="esprimo")
     */
    public function esPrimo($num){
        $result = $this->primo($num);
        return $this->render('esprimo.html.twig', array('num'=> $num, 'result'=>$result));
    }

    public function primo($numero){
        if(!is_numeric($numero)){
            return false;
        }
        for ($i = 2; $i < $numero; $i++) {
            if (($numero % $i) == 0) {
                return false;
            }
        }
        return true;
    }
}