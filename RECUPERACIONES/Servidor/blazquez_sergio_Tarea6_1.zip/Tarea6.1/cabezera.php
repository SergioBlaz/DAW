<nav>
    <ul>
        <li><a href='mejores.php'>Mejores</a></li>
        <li><a href='mejores_posicion.php'>Mejores por Posición</a></li>
        <li><a href='jugadores.php'>Jugadores</a></li>
        <li><a href='ver_estadisticas.php'>Estadísticas</a></li>
        <li><a href='nueva_ficha.php'>Nueva Ficha</a></li>
        <li><a href='logout.php'>Salir</a></li>
    </ul>
</nav>